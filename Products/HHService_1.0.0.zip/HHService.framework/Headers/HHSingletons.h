//
//  HHSingletons.h
//  HHServiceSDK
//
//  Created by haohao on 2018/11/8.
//  Copyright © 2018年 haohao. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HHSingletons : NSObject

+(HHSingletons *)sharedInstance;

@end

